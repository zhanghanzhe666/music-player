

class WebViewException(Exception):
    pass

class JavascriptException(Exception):
    pass